// Name: Kiru and Karman, Date: 4/4/23, Program Description: Implementation of a linked list ADT

global using NUnit.Framework;